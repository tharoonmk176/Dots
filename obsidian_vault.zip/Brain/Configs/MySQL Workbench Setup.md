---
tags:
  - config
  - mysql
  - mariadb
  - archlinux
  - hyprland
date: 2026-07-25
---

# 🐬 MySQL Workbench & MariaDB Setup Guide (Arch Linux / Hyprland)

Documentation for configuring MariaDB server and connecting it with MySQL Workbench on Arch Linux running Hyprland.

---

## 📌 Connection Credentials Summary

| Property | Value | Notes |
| :--- | :--- | :--- |
| **Host / IP** | `127.0.0.1` or `localhost` | Standard local loopback |
| **Port** | `3306` | Default MySQL/MariaDB port |
| **User** | `root` | Superuser account |
| **Password** | `asd` | Configured password |
| **Service Name** | `mariadb.service` | Systemd service |
| **Config File** | `/etc/my.cnf` | Global server configuration |

---

## ⚙️ Configuration & Setup Steps

### 1. MariaDB System Tables Initialization
On fresh Arch Linux installations, the MariaDB data directory must be initialized before starting the daemon:
```bash
sudo mariadb-install-db --user=mysql --basedir=/usr --datadir=/var/lib/mysql
```

### 2. Enable & Start Systemd Service
```bash
sudo systemctl enable --now mariadb.service
```

Verify service status:
```bash
systemctl status mariadb.service
```

---

### 3. Configure Root User Password & Remote/Local Access
By default, MariaDB uses socket authentication for `root`. To allow password authentication via MySQL Workbench TCP connections:

```sql
-- Set password for root@localhost
ALTER USER 'root'@'localhost' IDENTIFIED BY 'asd';
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;

-- Create and grant root@127.0.0.1 for TCP connection in Workbench
CREATE USER IF NOT EXISTS 'root'@'127.0.0.1' IDENTIFIED BY 'asd';
GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' WITH GRANT OPTION;

FLUSH PRIVILEGES;
```

---

### 4. Fix MySQL Workbench Config Parsing (`/etc/my.cnf`)
MySQL Workbench requires an explicit `[mysqld]` section in `/etc/my.cnf` to inspect and manage server configuration settings.

Update `/etc/my.cnf`:
```ini
[client-server]

[mysqld]
datadir=/var/lib/mysql
socket=/run/mysqld/mysqld.sock

!includedir /etc/my.cnf.d
```

Restart MariaDB after updating `/etc/my.cnf`:
```bash
sudo systemctl restart mariadb.service
```

---

### 5. Hyprland Keyring Requirement (`gnome-keyring`)
MySQL Workbench relies on `org.freedesktop.secrets` DBus API to store database passwords securely. 

> [!important] Keyring Service on Hyprland
> Ensure `gnome-keyring-daemon` is running in your Hyprland environment to avoid the `"The name is not activatable"` DBus error when storing connection passwords in Workbench.

---

## 🛠️ Quick CLI Commands

> [!tip] Verification & Test Commands
> - **Test TCP Connection**:
>   ```bash
>   mariadb -u root -pasd -h 127.0.0.1 -e "SHOW DATABASES;"
>   ```
> - **Test Socket Connection**:
>   ```bash
>   mariadb -u root -pasd -h localhost -e "SHOW DATABASES;"
>   ```
> - **Launch MySQL Workbench**:
>   ```bash
>   mysql-workbench
>   ```
