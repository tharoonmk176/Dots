For Timeshift backups = timeshift-gtk  
For rofi  = rofi -show drun
For [[Nvim]] Editor : C
For [[fastfetch config]]  generation = fastfetch --gen-config
For Claude code = using the [[API key for NVIDIA]]
For Ask Gemini in chrome = chrome://flags
-- select glic and switch to ***enabled***
For the MySQL workbench = 

For cloudfare warp - sudo systemctl enable --now warp-svc && warp-cli registration new && warp-cli connect



















LEGEND : 
	CODE - C