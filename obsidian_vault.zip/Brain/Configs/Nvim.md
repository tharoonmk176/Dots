# yazi.toml
[mgr]
show_hidden = true

[opener]
edit = [
    { run = 'nvim "$@"', block = true, for = "unix" }
]
