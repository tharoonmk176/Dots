# MeetSync Frontend Development Plan & Route Tree

This document outlines the component structure, route layout, and design system tokens for the MeetSync React frontend. It serves as our blueprint.

## 1. File Map / Component & Route Tree

All paths are relative to the `/src` folder:

```
src/
├── main.jsx                 # Application entry point
├── App.jsx                  # Main wrapper, Router, and global layout
├── index.css                # Global CSS, typography, and styling resets
├── contexts/
│   └── AuthContext.jsx      # Authentication & permissions context (JWT & role claims)
├── components/
│   ├── ProtectedRoute.jsx   # Route wrapper enforcing auth and role permissions
│   ├── ErrorBoundary.jsx    # Global React Error Boundary for runtime crashes
│   ├── NavBar.jsx           # Global Navigation Bar (responsive, dynamic auth states)
│   └── Footer.jsx           # Simple global footer
├── services/
│   └── api.js               # Centralized HTTP client + mock API layer (fallback)
└── pages/
    ├── Landing.jsx          # Public Landing Page (Light Theme)
    ├── Login.jsx            # Sign In (Dark Theme layout)
    ├── Register.jsx         # Multi-step Sign Up with validation & debounced email checks
    ├── Dashboard.jsx        # Role-aware dashboard with KPIs and activities
    ├── MeetingCalendar.jsx  # Calendar (week/month) + slide-out scheduler (conflict detection)
    ├── MeetingDetail.jsx    # Meeting details with Overview, AI Minutes, Action Items, Attachments
    ├── ActionItems.jsx      # Kanban / Table board with filters and status mutations
    ├── Analytics.jsx        # Data summaries, dynamic SVG charts, and SLA reports
    └── Admin.jsx            # Admin views: User Management, append-only Audit Logs, System Health
```

---

## 2. Design Tokens

Theme tokens will be defined in `src/index.css` using CSS custom properties.

### Light Theme (Landing Page)
- **Background**: `#ffffff` (Page), `#f8f9fa` (Section/Card)
- **Text**: `#0f0f14` (Primary), `#4a4a5a` (Secondary)
- **Border**: `#e5e7eb`
- **Accent Primary**: `#5b4ff5` (Indigo/violet)
- **Accent Hover**: `#483ddb`

### Dark Theme (Authenticated App Shell & Auth pages)
- **Background**: `#0f0f14` (Page), `#13131a` (Slightly lighter panels), `#1a1a24` (Cards/Components)
- **Text**: `#f8f9fa` (Primary/Off-white), `#a1a1b5` (Secondary)
- **Border**: `#2a2a38`
- **Accent Primary**: `#5b4ff5` (Indigo/violet)
- **Accent Hover**: `#7266ff`

### Shared / Semantic Colors
- **Scheduled**: `#4f46e5` (Indigo)
- **In Progress / On Track**: `#10b981` (Green)
- **Completed**: `#6b7280` (Gray)
- **Cancelled / Overdue**: `#ef4444` (Red)
- **At Risk / Warning**: `#f59e0b` (Amber)
- **Pending / Neutral**: `#9ca3af` (Light Gray)
- **Card Radius**: `12px`
- **Animation Transitions**: `all 0.2s cubic-bezier(0.4, 0, 0.2, 1)`

---

## 3. Implementation Order

1. **Design Tokens (`src/index.css`)**: Implement CSS variables, typography (Inter), and layout utilities.
2. **Mock API & Client (`src/services/api.js`)**: Seed database-grade mock data conforming to MySQL enums, export functions for CRUD.
3. **AuthContext (`src/contexts/AuthContext.jsx`) & ProtectedRoute**: Manage user sessions, auto-logout (30m), and helper rules `can(role, action)`.
4. **App Shell Routing (`src/App.jsx`, NavBar, Footer, ErrorBoundary)**: Hook up React Router and verify landing/app shell navigation.
5. **Auth Screens (`Landing.jsx`, `Login.jsx`, `Register.jsx`)**: Validation, password toggles, debounced email uniqueness check.
6. **Dashboard (`Dashboard.jsx`)**: Responsive KPI grid, Recent Activity, agenda.
7. **Calendar (`MeetingCalendar.jsx`)**: Week/month toggle, schedule side-drawer with participant list conflict check.
8. **Details (`MeetingDetail.jsx`)**: Four tabbed panels, attendee approval list with timestamps, attachments.
9. **Action Items (`ActionItems.jsx`)**: Kanban Board + Table layout toggles.
10. **Analytics (`Analytics.jsx`)**: Custom SVG line/pie/bar charts and SLA export.
11. **Admin (`Admin.jsx`)**: User list (with mock API persistence) and append-only audit logger.
12. **Build Notes Memo**: Summary of all implemented features.
