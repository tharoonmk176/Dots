# MASTER PROMPT — MeetSync Database Design Generation

> Copy everything below into your AI IDE (Cursor / Windsurf / Claude Code / Copilot Chat) as a single prompt. It is self-contained: it gives the AI full project context, every entity and field the SRS and existing design imply, and an exact deliverable spec so it produces a complete, production-ready database design in one pass instead of guessing at your schema.

---

## ROLE

You are a senior backend architect. Design the **complete relational database** for **MeetSync** — an Automated Meeting Scheduling and AI Minutes Generation Platform — for a **Spring Boot 3.x (Java 17+) + Spring Data JPA + MySQL 8.0+** backend. Target MySQL specifically — use its native types and syntax (e.g. `ENUM(...)` columns, `AUTO_INCREMENT`, `JSON` type, `utf8mb4` charset with `utf8mb4_unicode_ci` collation, `InnoDB` engine for FK/transaction support) rather than writing generic ANSI SQL.

## PROJECT CONTEXT (read this before designing anything)

MeetSync lets teams **schedule meetings, auto-generate minutes from transcripts using AI, track action items to completion, log decisions, and get analytics on meeting effectiveness.** It replaces manual calendar coordination and manual minute-taking.

Confirmed product surface (from the SRS and UI):
- **Landing + Auth**: marketing landing page, login (email/password), registration, JWT-based sessions.
- **Dashboard**: role-aware KPI cards (upcoming meetings, pending action items, overdue items, meeting hours/week), recent activity feed, "this week" agenda, quick actions.
- **Meeting Calendar**: week/month view, a "Schedule Meeting" side panel (date, time, duration, mode: Virtual/In-Person/Hybrid, room picker, participant picker with conflict detection, auto-generated video link).
- **Meeting Detail**: tabs for Overview (agenda list, description), Minutes (AI-generated summary + key decisions + per-attendee approval history with an "Approve Minutes" action), Action Items (table: description, owner, due date, priority, status), Attachments (file list with uploader and size).
- **Action Items board**: table/kanban toggle, filters by status (Open/In Progress/Completed/Overdue), owner avatars, due dates, priority tags.
- **Analytics**: total meetings, avg duration, action completion %, avg attendees, meetings-per-week trend line, meeting-mode split (donut), action completion by team (bar), a per-meeting SLA report (On Track / At Risk / Overdue / Pending) exportable to PDF/Excel/CSV.
- **Admin Panel**: User Management (name, email, role, status, last login, edit/disable), System Config, Audit Logs (user, action, resource, timestamp, IP address), System Health.

Non-functional posture the schema must support: RBAC enforced at the data layer, immutable/tamper-evident audit logging of every access and mutation, AES-256 field-level encryption for sensitive data, soft-deprecation via status enums rather than hard deletes where audit history matters, 7-year minimum audit log retention, and 500+ concurrent users with sub-2-second CRUD.

## AUTHORITATIVE SOURCE MATERIAL

I'm giving you three source documents — **synthesize all three, don't just copy one**:

1. **SRS (Software Requirements Specification)** — defines functional requirements (FR1–FR17), validation rules (Appendix C), exception classes (Appendix E), and a *partial* logical schema (section 3.4 + Appendix B) covering only Users, Meetings, MeetingMinutes, ActionItems, MeetingRooms.
2. **Existing DB Design doc** — extends the SRS schema with the tables the SRS's functional requirements clearly need but didn't formalize: MeetingParticipants, Documents, Notifications, AuditLog. Includes an ER diagram and sample data.
3. **UI/UX screens (MeetSync)** — the real, built-out product surface. Use these to catch fields the text specs imply but never explicitly listed (e.g., the Minutes tab shows *per-attendee approval status with timestamps*, not just a single `approved_by` — the current schema under-models this; the Attachments tab shows file size and per-file uploader; the SLA report implies a computed/derived view, not a new stored table).

**Your job**: reconcile all three into one coherent, de-duplicated, production-grade schema — resolving the gaps between the SRS's minimal schema and what the UI actually requires, and flagging every place you had to make an inference.

## ENTITIES TO DESIGN (confirmed baseline — extend as the requirements demand)

For each table below, derive full column list (types, nullability, defaults, constraints) from the SRS validation rules, the DB design doc, and the UI screens — do not just restate the abbreviated field lists given here.

1. **users** — id, name (alphabetic + spaces only, 2–100 chars), phone_number (exactly 10 digits), email (unique), password_hash, role (enum: GUEST, ATTENDEE, ORGANISER, MANAGER, ADMIN — see Appendix A permission matrix), created_date, last_login, is_active.
2. **meeting_rooms** — id, name, location, capacity, amenities, status (AVAILABLE/OCCUPIED/MAINTENANCE).
3. **meetings** — id, title, organiser_id (FK→users), meeting_date (must be future on create), duration_minutes (positive int), mode (IN_PERSON/VIRTUAL/HYBRID), room_id (FK, nullable for virtual-only), video_link, status (SCHEDULED/IN_PROGRESS/COMPLETED/CANCELLED), plus fields the UI needs that the SRS doesn't list: description/agenda text, created_at/updated_at.
4. **meeting_participants** — id, meeting_id (FK), user_id (FK), attendance_status (e.g., CONFIRMED/PENDING/DECLINED), joined_at.
5. **meeting_minutes** — id, meeting_id (FK, one-to-one), agenda, summary, decisions (JSON), attendees (JSON), generated_by (AI/MANUAL), approved_by (FK), created_at. **Flag this to the AI**: the UI shows *multiple attendees each independently approving* with individual timestamps (Sarah Kim — Approved Jul 10, 14:23; Mike Roberts — Approved Jul 10, 15:01; Priya Nair — Pending) — a single `approved_by` FK cannot represent this. Design a `minutes_approvals` junction table (minutes_id, user_id, status, approved_at) and treat `approved_by` on the parent as derived/deprecated.
6. **action_items** — id, meeting_id (FK), description, owner_id (FK), due_date, priority (HIGH/MEDIUM/LOW), status (OPEN/IN_PROGRESS/COMPLETED/OVERDUE), created_at.
7. **documents** — id, meeting_id (FK), file_name, file_type, uploaded_by (FK), version, uploaded_at. Add file_size (the UI displays "4.2 MB", "1.8 MB" per attachment).
8. **notifications** — id, user_id (FK), meeting_id (FK), type, channel (in-app/email/SMS per FR8), status, sent_at.
9. **audit_log** — id, user_id (FK), action, entity_type, entity_id, timestamp. Add ip_address (the Admin > Audit Logs screen displays it per row) and make this table **append-only** (no update/delete permission at the application layer — enforce via DB grants or triggers, per FR12/FR15's tamper-evident requirement).

## GAPS BETWEEN THE SRS TEXT AND THE ACTUAL UI — RESOLVE THESE EXPLICITLY

- **Decision log**: SRS 1.2 lists "Decision log with searchable history" as a distinct feature, but the schema only has a `decisions` JSON blob inside `meeting_minutes`. Decide and justify: keep decisions embedded (simpler, matches current sample data) vs. extract to a normalized `decisions` table with its own id/meeting_id/text/created_at (enables the "searchable history" requirement properly — recommended if full-text search across decisions is needed).
- **SLA / analytics numbers** (On Track / At Risk / Overdue / 75% / 50% completion): these look computed from `action_items` + `meetings`, not separately stored. Design them as SQL views or application-layer aggregates — do not create a redundant `meeting_sla` table unless you add a caching justification.
- **Role permission matrix** (Appendix A) should be enforceable from data, not hardcoded — consider a `role_permissions` table (role, resource, permission) so FR3's "permission matrix maintained in database for runtime enforcement without code deployment" is actually satisfiable.
- **Recurring meetings** (FR6 lists "Recurring schedule configuration") — the current schema has no way to represent a recurrence series. Add a `recurrence_rule` (e.g., RRULE string) and `parent_meeting_id` (self-FK) on `meetings`, or a separate `meeting_series` table — pick one and justify.
- **Notification preferences** (FR8: "user notification preference management per channel and type") isn't modeled anywhere — add a `notification_preferences` table (user_id, type, channel, enabled).

## NON-NEGOTIABLE CONSTRAINTS

- Every table: surrogate PK (`id`), explicit FKs with `ON DELETE` behavior chosen deliberately (e.g., `RESTRICT` on `meetings.organiser_id`, `CASCADE` on `meeting_participants.meeting_id`) and justified in a comment.
- Enforce SRS Appendix C validation rules at the DB level wherever the DB can express them (CHECK constraints for phone length, UNIQUE on email) in addition to application-layer validation.
- `password_hash` never stores plaintext; no password field is ever `SELECT *`-exposed — note this as an application-layer concern in comments.
- Timestamps: every table gets `created_at`; mutable tables get `updated_at`.
- Index every FK, plus `meetings.meeting_date`, `action_items.due_date`, `action_items.status`, `users.email`.
- Match the custom exception classes in `com.examly.springapp.exception` (InvalidNameException, InvalidPhoneException, DuplicateMeetingException, UnauthorisedAccessException, ResourceNotFoundException) to the constraints that would trigger them.

## DELIVERABLES — produce ALL of the following

1. **Reconciled ER diagram** (Mermaid `erDiagram` syntax) showing every table, column, type, PK/FK, and cardinality.
2. **Full DDL in MySQL 8.0+ dialect** — every table, constraint, index, and enum (use native MySQL `ENUM(...)` columns for role/status/priority/mode fields, `AUTO_INCREMENT` PKs, `InnoDB` engine, explicit `FOREIGN KEY ... ON DELETE ...` clauses, and `CHECK` constraints for the phone-length and future-date rules — MySQL 8.0.16+ enforces `CHECK`).
3. **JPA entity classes** (Java 17, `jakarta.persistence`) mirroring the DDL exactly — `@Entity`, `@Table`, `@Column` constraints, `@ManyToOne`/`@OneToMany`/`@OneToOne` mappings matching the relationships list in the DB design doc, and `@Enumerated(EnumType.STRING)` for all status/role/priority fields. Include the matching `application.properties`/`application.yml` snippet: `spring.datasource.url=jdbc:mysql://localhost:3306/meetsync`, `spring.jpa.database-platform=org.hibernate.dialect.MySQL8Dialect` (or `MySQLDialect` on Hibernate 6+), and `spring.jpa.hibernate.ddl-auto=validate` (schema owned by the DDL/migration scripts, not Hibernate auto-generation).
4. **A short design-decisions memo** listing every place you deviated from or extended the source SRS/DB-design doc, and why (this is the most important deliverable — I need to see your reasoning, not just output).
5. **Sample seed data** (SQL inserts) consistent with the sample data already in the DB design doc (Ananya/Vikram/Meera/Karthik, Sprint Planning/Client Review) so it plugs into the existing dataset without conflicts.

## OUTPUT FORMAT

Work in this order: (1) design-decisions memo first, (2) ER diagram, (3) DDL, (4) JPA entities, (5) seed data. Do not skip the memo — a schema without reasoning is not acceptable for this project.
