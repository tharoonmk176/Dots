# MASTER PROMPT — MeetSync Frontend Build

> Copy everything below into your AI IDE (Cursor / Windsurf / Claude Code / v0 / Copilot Chat) as a single prompt. It gives the AI the full product surface (from the actual UI screens), the component architecture the SRS already specifies, and the design system to match — so it builds pixel-consistent screens instead of guessing at layout.

---

## ROLE

You are a senior frontend engineer. Build the **complete React frontend** for **MeetSync** — an Automated Meeting Scheduling and AI Minutes Generation Platform — using **React.js + React Router DOM v6**, consuming a Spring Boot + JWT REST API on port 8080, served from port 8081.

## PROJECT CONTEXT

MeetSync replaces manual calendar coordination and manual minute-taking: users schedule meetings, AI generates minutes from transcripts, action items get tracked to completion, decisions get logged, and managers get analytics on meeting effectiveness. Five roles exist with escalating access: **Guest → Attendee → Organiser → Manager → Admin** (see the permission matrix below — it must drive what each screen shows and hides, not just what the API blocks).

## DESIGN SYSTEM (derived from the actual UI — match this exactly, don't invent a new look)

- **Theme**: dark mode as default/primary surface (near-black background, e.g. `#0f0f14`–`#13131a`), off-white text, card surfaces one shade lighter than the page background with subtle borders, not hard drop-shadows.
- **Accent**: indigo/violet primary (`#5b4ff5`-ish purple-blue), used for primary buttons, active nav state, and the logo mark (a lightning-bolt icon in a rounded-square badge).
- **Landing page is light-themed** (white background) while the **authenticated app is dark-themed** — build both theme tokens, don't force one palette everywhere.
- **Typography**: clean sans-serif, bold large headline weight on the landing hero ("Stop losing time to **unproductive** meetings" — accent color on the key phrase), medium weight for card titles, regular for body/meta text.
- **Status color coding** used consistently everywhere (badges, dots, kanban columns): Scheduled = blue/indigo, In Progress = green, Completed = gray/neutral, Cancelled/Overdue = red, At Risk = amber/orange, On Track = green, Pending = gray.
- **Cards**: rounded corners (~12px), compact padding, an icon badge in a tinted rounded-square in the top-left of KPI cards, big number + small label + small delta line ("+12% vs last period").
- **Avatars**: colored circular initials badges (2-letter initials, distinct background color per person) used everywhere a user is referenced — assignee, organiser, uploader, approver.

## APPLICATION SHELL & ROUTING (from SRS Appendix I — implement exactly)

**App.jsx**
- React Router DOM v6 with nested and protected routes.
- Routes: `/` (Home/landing), `/login`, `/register`, `/dashboard`, `/meetings` (calendar), plus meeting detail, action items, analytics, and admin routes implied by the UI (add `/meetings/:id`, `/action-items`, `/analytics`, `/admin`).
- `NavBar` and `Footer` rendered once in the root layout, not per-page.
- `ProtectedRoute` wrapper redirects unauthenticated users to `/login`.
- Global `ErrorBoundary` around the route outlet for unhandled runtime exceptions.

**NavBar.jsx**
- App title/logo: "MeetSync" with the lightning-bolt badge icon.
- Logged-out state (landing): "Features", "Pricing", "Login" links + a prominent "Get Started" button.
- Logged-in state (app shell): horizontal tab nav — Dashboard, Meetings, Action Items, Analytics, Admin (Admin only visible if role has access per the permission matrix) — plus a right-aligned cluster: theme toggle, notification bell (with unread dot), and a user menu (avatar + name + role, dropdown for profile/logout).
- Read logged-in user's name and role from JWT claims via `AuthContext`.
- Logout clears JWT from storage and redirects to `/login`.
- CSS classes: `nav-link`, `nav-active`, `nav-brand`.

**Login.jsx**
- Email/username + password fields, password show/hide toggle, "Forgot password?" link.
- Submit → `POST /api/auth/login`; store JWT + role in `AuthContext`; redirect to role-specific dashboard from the JWT role claim.
- Error state: "Invalid credentials. Please check your email and password."
- "Don't have an account? Create one free" link to `/register`.

**Register.jsx**
- Multi-step form: name, email, phone, role, then role-specific fields.
- Client-side validation matching the SRS rules exactly (see Validation section below), enforced before submit, mirrored server-side.
- Debounced async email-uniqueness check while typing.
- Submit → `POST /api/auth/register`; success message: "Registration successful! Please verify your email."

**Dashboard.jsx**
- Personalized greeting header ("Good morning, {firstName}") + current date + role, with a primary "+ Schedule Meeting" button top-right.
- Four KPI cards in a row: Upcoming Meetings (with "Next: {title}, {time}" subtext), Pending Action Items (with "{n} assigned to you" subtext), Overdue Items (with "Needs immediate attention" subtext, red accent), Meeting Hours/Week (with a week-over-week delta).
- Two-column lower section: left = "Recent Activity" feed (avatar + actor name + action + linked entity + relative timestamp, "View all" link), right = "This Week" agenda list (title, date/time, a small mode icon) + a "Quick Actions" panel.
- Role-aware: card contents and quick actions differ per role, but the *layout* stays constant.
- Responsive grid: single column on mobile, multi-column on desktop.

**MeetingCalendar.jsx** (route: `/meetings`)
- Week/Month toggle, week-of header, "+ Schedule" button opening a right-side slide-over panel.
- Grid: hour rows × day columns, meetings rendered as colored blocks positioned/sized by start time and duration, colored by mode or status per the legend at the bottom (Scheduled/In Progress/Completed/Cancelled).
- Schedule panel fields: date, time, duration (dropdown), mode (segmented control: Virtual/In-Person/Hybrid), room (dropdown, only enabled for In-Person/Hybrid), participants (typeahead multi-select showing avatar chips), an inline conflict-warning banner ("{name} has a conflict at {time}. Consider {altTime} instead."), auto-generated video link field (read-only, populated on room/participant selection), "Create Meeting" submit.

**MeetingDetail.jsx** (route: `/meetings/:id`)
- Breadcrumb ("Meetings > {title}"), status + mode badges, title, date/time/duration/location line, Organiser avatar+name, attendee avatar stack (+N overflow), "Edit" and "Join Meeting" actions.
- Tab bar: Overview | Minutes | Action Items ({count} badge) | Attachments ({count} badge).
  - **Overview**: numbered agenda list with per-item duration, a description block.
  - **Minutes**: an "AI-Generated Minutes" banner ("Auto-generated from transcript · {n} of {total} attendees approved"), Summary paragraph(s), "Key Decisions" checklist, "Approval History" list (per-attendee avatar + name + status: Approved with timestamp, or Pending) + an "Approve Minutes" button for eligible roles.
  - **Action Items**: table — Description, Owner (avatar+name), Due, Priority (colored badge), Status (colored badge).
  - **Attachments**: file list — file-type icon, file name, size, uploader, upload date, "+ Upload" action.

**ActionItems.jsx** (route: `/action-items`)
- Header with item count ("{n} items across all meetings"), Table/Kanban view toggle, search box, status filter chips (All/Open/In Progress/Overdue/Completed), Filters button, "+ Add Item" button.
- Kanban: one column per status, each card showing description, priority badge, assignee avatar+name, due date.
- Table view: sortable columns matching the card fields.

**Analytics.jsx** (route: `/analytics`)
- Period selector ("Last 7 weeks") + department filter + Export button.
- Four summary cards: Total Meetings, Avg Duration, Action Completion %, Avg Attendees (each with a delta/target subtext).
- Charts: "Meetings per Week" line/area chart, "Meeting Mode Split" donut chart, "Action Item Completion by Team" bar chart.
- "Meeting SLA Report" table: Meeting, Date, Duration, Attendees, Action Items, Completion %, SLA badge (On Track/At Risk/Overdue/Pending); export buttons for PDF/Excel/CSV.

**Admin.jsx** (route: `/admin`, Admin role only)
- Left sub-nav: User Management, System Config, Audit Logs, System Health.
- **User Management**: table (Name, Email, Role, Status, Last Login, Edit/Disable actions), "+ Add User" button.
- **Audit Logs**: table (User, Action, Resource, Timestamp, IP Address), "Export Logs" button — read-only, no edit/delete affordance anywhere in this view (the log is append-only).

**Footer.jsx**
- "© 2026 MeetSync. All rights reserved." + links to privacy policy, terms of service, support.
- Rendered once via the App.jsx layout, never imported into individual pages.

## STATE / DATA LAYER

- `AuthContext` holding JWT, decoded role/user claims, login/logout methods; JWT persisted client-side and attached to every API call via an Authorization header.
- API client layer (fetch or axios) with a base URL pointing at the Spring Boot backend, one module per resource matching the SRS's Appendix H endpoints (`/api/meetings`, `/api/minutes`, `/api/action-items`, `/api/rooms`, `/api/auth`, `/api/users/profile`).
- Enum-backed fields (role, meeting status, mode, action item status, priority, room status) must use the **exact same string values as the backend's MySQL `ENUM` columns** (e.g. `SCHEDULED`, `IN_PROGRESS`, `COMPLETED`, `CANCELLED` for meeting status) — don't invent display-only values without a mapping layer, since the API will reject or silently mismatch anything that doesn't match the DB enum verbatim.
- Role-based UI gating: a small helper (e.g. `can(role, action)`) driven by the permission matrix below, used to hide/disable nav items, buttons, and routes — not just to hide API calls.

## PERMISSION MATRIX (drive conditional rendering from this — Appendix A of the SRS)

| Feature | Guest | Attendee | Organiser | Manager | Admin |
|---|---|---|---|---|---|
| View Public Meetings | – | ✓ | ✓ | ✓ | ✓ |
| Schedule Meeting | – | limited | ✓ | ✓ | ✓ |
| View Minutes | – | ✓ | ✓ | ✓ | ✓ |
| Approve Minutes | – | – | ✓ | ✓ | ✓ |
| Manage Action Items | – | ✓ | ✓ | ✓ | ✓ |
| View Analytics | – | – | limited | ✓ | ✓ |
| Manage Rooms | – | – | – | ✓ | ✓ |
| Manage Users / Audit Logs / System Config | – | – | – | – | ✓ |

## VALIDATION RULES (enforce client-side, mirroring the backend exactly)

| Field | Rule | Error message |
|---|---|---|
| Name | Alphabetic + spaces only, 2–100 chars | "Name must not contain numbers or special characters" |
| Phone | Exactly 10 digits | "Phone Number must be exactly 10 digits long" |
| Email | Valid format, unique | "Please enter a valid email address" / "This email is already registered" |
| Password | Min 8 chars, upper+lower+digit+special | "Password must meet security requirements" |
| Meeting Date | Must be a future date/time | "Meeting must be a future date" |
| Duration | Positive integer minutes | "Duration must be positive" |

## NON-FUNCTIONAL REQUIREMENTS

- Mobile-responsive throughout (WCAG 2.1 AA target); touch-friendly tap targets on calendar and kanban views.
- Auto-logout after 30 minutes of inactivity (mirrors backend session policy) with a warning toast before expiry.
- Optimistic UI for status-only mutations (action item status, minutes approval) with rollback on API failure.
- Cross-browser: Chrome 100+, Firefox 100+, Edge 100+, Safari 15+.

## DELIVERABLES — produce ALL of the following

1. **Component/route tree** as a file map before writing any code, matching the structure above.
2. **Design tokens file** (colors, spacing, radii, typography scale) for both the light landing theme and the dark app theme.
3. **Full component implementation** for every screen listed above, wired to the API client layer (mock the API layer if no live backend is reachable — clearly mark mocked calls with a `// TODO: replace with live endpoint` comment).
4. **AuthContext + ProtectedRoute + role-gating helper**, fully wired into the route tree.
5. **A short build notes memo** listing any UI details you had to infer beyond what's specified here, and why.

## OUTPUT FORMAT

Work in this order: (1) component/route tree, (2) design tokens, (3) AuthContext/routing/auth screens, (4) Dashboard, (5) MeetingCalendar + MeetingDetail, (6) ActionItems, (7) Analytics, (8) Admin, (9) build notes memo last.
