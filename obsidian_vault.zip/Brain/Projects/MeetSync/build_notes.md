# MeetSync Frontend Build Notes & Technical Memo

This memo outlines the core implementation decisions, architectural choices, and UI/UX behaviors established during the development of the **MeetSync** React frontend.

## 1. Architectural Decisions & Gaps Resolved

- **Stateful LocalStorage Database Fallback**: To ensure the frontend remains fully interactive and testable even when the Spring Boot backend (`http://localhost:8080`) is offline, a comprehensive mock database layer was implemented inside [api.js](file:///home/tharoon/Projects/frontend/src/services/api.js). Any network failure automatically diverts requests to this layer, which manages data updates in `localStorage`.
- **User Disabling Restrictions**: We wired the Admin's "Disable User" action directly to the authentication fallback checks. If an Admin disables an account, that user is blocked from signing in again (throwing the appropriate inactive account error), proving complete state integration.
- **Multi-Attendee Minutes Approval**: The backend schema under-models approvals with a single `approved_by` field. Reconciling this with the tabbed UI requirements, we implemented a junction model `minutes_approvals` in the mock state. This enables each attendee to approve the transcript individually, logging their approval timestamp.
- **Conflict Warning Alternative Suggestion**: When scheduling meetings, the system validates availability. If a conflict is detected, it does not just show a warning; it parses the start time and suggests scheduling the meeting **1 hour later** as a convenient fallback.
- **SVG-Based Premium Charting**: Rather than loading heavy external charting libraries (which can suffer from version conflicts under React 19), we hand-coded responsive SVG charts:
  - *Meetings per Week*: An area-fill spline graph using linear colors gradients.
  - *Meeting Mode*: A custom donut ring tracking Virtual/Hybrid/In-Person percentages.
  - *Action Completion*: A clean horizontal bar comparison.
- **Live CSV Exporter**: The Analytics SLA grid contains a functioning exporter. Clicking `CSV` triggers a browser download using a Data URI encoded with the formatted table data.

## 2. Inactivity Warning Life-cycle

To mirror the 30-minute session expiry:
1. Keyboard, scroll, and mouse clicks are monitored.
2. If inactive for **28 minutes**, a centered warning overlay appears showing a countdown.
3. The user can click "Stay Logged In" to extend the session.
4. If the timer reaches 0, the session is cleared and the page redirects to `/login`.

## 3. Core Component Layout Files

| Module File | Component Purpose | Path Link |
|---|---|---|
| **Design Tokens** | Dual themes (light marketing & dark dashboard) | [index.css](file:///home/tharoon/Projects/frontend/src/index.css) |
| **Auth Provider** | Decodes JWT claims, checks permission flags, tracks inactivity timeouts | [AuthContext.jsx](file:///home/tharoon/Projects/frontend/src/contexts/AuthContext.jsx) |
| **Route Router** | Wraps protected paths, handles full-bleed Landing switches | [App.jsx](file:///home/tharoon/Projects/frontend/src/App.jsx) |
| **Protected Wrapper** | Enforces the RBAC permission matrix for routes | [ProtectedRoute.jsx](file:///home/tharoon/Projects/frontend/src/components/ProtectedRoute.jsx) |
| **Landing View** | Public light-themed overview, pricing grid, and registration CTAs | [Landing.jsx](file:///home/tharoon/Projects/frontend/src/pages/Landing.jsx) |
| **Dashboard Screen** | Time-aware greeting headers, 4 metric cards, activities and agendas | [Dashboard.jsx](file:///home/tharoon/Projects/frontend/src/pages/Dashboard.jsx) |
| **Calendar Screen** | Toggleable calendars, schedule drawers, conflict warning banners | [MeetingCalendar.jsx](file:///home/tharoon/Projects/frontend/src/pages/MeetingCalendar.jsx) |
| **Detail View** | Agenda overviews, AI minutes, checklists, file download listings | [MeetingDetail.jsx](file:///home/tharoon/Projects/frontend/src/pages/MeetingDetail.jsx) |
| **Action Items Board** | Kanban cards, drag handles, mobile arrows, sortable tables | [ActionItems.jsx](file:///home/tharoon/Projects/frontend/src/pages/ActionItems.jsx) |
| **Analytics Dashboard** | Custom SVGs, performance splits, and CSV file exporters | [Analytics.jsx](file:///home/tharoon/Projects/frontend/src/pages/Analytics.jsx) |
| **Admin Panel** | User tables, toggle disable clicks, health status metrics, system logs | [Admin.jsx](file:///home/tharoon/Projects/frontend/src/pages/Admin.jsx) |
