OmniRoute 
Agentic swarm for Personal API
COCO CLI - during CIA