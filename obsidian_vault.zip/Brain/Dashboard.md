# 🧠 Brain Dashboard

Welcome to your central knowledge hub & Obsidian Map of Content (MOC).

---

## 📁 Vault Structure

> [!tip] Quick Navigation
> Click any link below to open the note directly in Obsidian.

### 🚀 Projects
- [[MeetSync]] — Project notes & frontend/backend tasks
- [[Backend Development 1]] — Backend architecture checklist
- [[Datahub]] — Personal API, OmniRoute, & CLI tools

---

### ⚙️ Configs & System Shortcuts
- [[Commands]] — System keyboard shortcuts, Timeshift, Rofi & tool shortcuts
- [[Nvim]] — Yazi & Neovim file opener configuration
- [[fastfetch config]] — Fastfetch system info formatting schema
- [[MySQL Workbench Setup]] — MariaDB server setup & MySQL Workbench configuration


---

### 🔐 Credentials & Secrets
- [[API key for NVIDIA]] — API keys & authentication credentials

---

> [!note] Organization Note
> Notes are categorized into `Projects/`, `Configs/`, and `Secrets/`. Standard Obsidian `[[wikilinks]]` continue to resolve seamlessly across all folders.
